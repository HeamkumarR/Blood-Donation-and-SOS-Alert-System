import React, { useState } from 'react';
import {
  Database,
  Server,
  Key,
  ShieldCheck,
  FileCode2,
  X,
  Copy,
  Check,
  Layers,
  MapPin,
  ExternalLink,
} from 'lucide-react';

interface DatabaseArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DatabaseArchitectureModal: React.FC<DatabaseArchitectureModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'SCHEMAS' | 'APIS' | 'GEOSPATIAL'>('OVERVIEW');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 text-emerald-400 flex items-center justify-center font-mono shadow-xs">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span>Production Database Architecture</span>
                <span className="text-[11px] font-mono font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                  MongoDB + Mongoose + Express
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                Final-Year Project Architecture · Tamil Nadu & Chennai Emergency Blood Network
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-200 bg-white text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('OVERVIEW')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'OVERVIEW'
                ? 'border-rose-600 text-rose-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Architecture Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('SCHEMAS')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'SCHEMAS'
                ? 'border-rose-600 text-rose-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileCode2 className="w-4 h-4" />
            <span>Mongoose Schemas (4 Models)</span>
          </button>

          <button
            onClick={() => setActiveTab('APIS')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'APIS'
                ? 'border-rose-600 text-rose-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>REST API Catalog & RBAC</span>
          </button>

          <button
            onClick={() => setActiveTab('GEOSPATIAL')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'GEOSPATIAL'
                ? 'border-rose-600 text-rose-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>2dsphere Geospatial Engine</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-slate-800 text-xs leading-relaxed">
          {activeTab === 'OVERVIEW' && (
            <div className="space-y-6">
              {/* Architecture diagram card */}
              <div className="p-4 rounded-xl bg-slate-900 text-slate-100 font-mono text-[11px] overflow-x-auto shadow-inner">
                <div className="text-emerald-400 font-bold mb-2">// Full-Stack MERN Architecture Flow</div>
                <pre>{`[ Client Layer: React 19 + Tailwind CSS + Google Maps Platform ]
                       │  ▲
                       │  │ JSON over HTTPS (JWT Bearer Token)
                       ▼  │
[ API Gateway: Express 4.x + CORS + Helmet + RateLimiting ]
       │
       ├── Middleware: protect (JWT Verify) & authorize('ADMIN' | 'USER')
       │
       ├── Controllers: Auth, Users, BloodRequests, SOSAlerts, Admin
       │
       ▼
[ Data Layer: MongoDB + Mongoose 8.x ]
       ├── Users Collection       -> 2dsphere index on location + compound index on bloodGroup
       ├── BloodRequests          -> ref: User (requester) + ref: User[] (assignedDonors)
       ├── SOSAlerts              -> 2dsphere index on location + automated radius notifier
       └── DonationHistories      -> unique certificateId + verified audit trail`}</pre>
              </div>

              {/* Core Features Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center gap-2 font-bold text-slate-900 text-xs mb-1">
                    <Key className="w-4 h-4 text-rose-600" />
                    <span>JWT & Bcrypt Security</span>
                  </div>
                  <p className="text-slate-600 text-[11px]">
                    Passwords hashed via bcrypt salt rounds (10) in pre-save hooks. 30-day JWT Bearer tokens with role payload for RBAC enforcement.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center gap-2 font-bold text-slate-900 text-xs mb-1">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <span>2dsphere GeoJSON Engine</span>
                  </div>
                  <p className="text-slate-600 text-[11px]">
                    Indexed GeoJSON Points for Chennai & Tamil Nadu districts. Enables sub-second `$near` donor searches within 15 km emergency radius.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center gap-2 font-bold text-slate-900 text-xs mb-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Privacy & RBAC Discipline</span>
                  </div>
                  <p className="text-slate-600 text-[11px]">
                    Strict field projection filters out personal emails, residential addresses, and phone numbers from user-facing search responses.
                  </p>
                </div>
              </div>

              {/* Folder Structure */}
              <div>
                <h4 className="font-bold text-slate-900 mb-2">Backend Folder Organization (/server)</h4>
                <div className="p-3 bg-slate-100 rounded-xl font-mono text-[11px] text-slate-700">
                  <p>/server/config/db.ts — Mongoose connection with retry & 2dsphere configuration</p>
                  <p>/server/models/ — User.ts, BloodRequest.ts, SOSAlert.ts, DonationHistory.ts</p>
                  <p>/server/middleware/ — auth.ts (JWT protect & authorize RBAC guard)</p>
                  <p>/server/controllers/ — authController, userController, requestController, sosController, adminController</p>
                  <p>/server/routes/ — authRoutes, userRoutes, requestRoutes, sosRoutes, adminRoutes</p>
                  <p>/server/seed/ — seedData.ts (Authentic Chennai & Tamil Nadu hospital & donor dataset)</p>
                  <p>/server/server.ts — Express entry point</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'SCHEMAS' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-900 text-slate-200 rounded-xl font-mono text-[11px] overflow-x-auto relative">
                <button
                  onClick={() => handleCopy(`// UserSchema sample code in /server/models/User.ts`, 'user_schema')}
                  className="absolute top-3 right-3 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] flex items-center gap-1"
                >
                  {copiedKey === 'user_schema' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedKey === 'user_schema' ? 'Copied' : 'Copy Schema'}</span>
                </button>
                <p className="text-emerald-400 font-bold mb-2">// 1. User & Donor Schema (Mongoose)</p>
                <pre>{`const UserSchema = new Schema({
  fullName: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, index: true },
  password: { type: String, required: true, select: false },
  phone: { type: String, required: true },
  bloodGroup: { type: String, required: true, enum: ['A+','A-','B+','B-','AB+','AB-','O+','O-'] },
  age: { type: Number, required: true, min: 18, max: 65 },
  gender: { type: String, enum: ['Male', 'Female', 'Other', 'Prefer not to say'] },
  city: { type: String, default: 'Chennai', index: true },
  district: { type: String, default: 'Chennai' },
  state: { type: String, default: 'Tamil Nadu' },
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], required: true, default: [80.2707, 13.0827] } // [lng, lat]
  },
  role: { type: String, enum: ['USER', 'ADMIN'], default: 'USER' },
  isDonor: { type: Boolean, default: true, index: true },
  isAvailable: { type: Boolean, default: true, index: true },
  totalDonations: { type: Number, default: 0 },
  verified: { type: Boolean, default: false }
});

// Geospatial 2dsphere index for proximity queries
UserSchema.index({ location: '2dsphere' });
UserSchema.index({ bloodGroup: 1, isAvailable: 1, isDonor: 1 });`}</pre>
              </div>

              <div className="p-4 bg-slate-900 text-slate-200 rounded-xl font-mono text-[11px] overflow-x-auto">
                <p className="text-emerald-400 font-bold mb-2">// 2. Blood Request Schema (Mongoose)</p>
                <pre>{`const BloodRequestSchema = new Schema({
  requester: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  patientName: { type: String, required: true },
  bloodGroup: { type: String, required: true, enum: ['A+','A-','B+','B-','AB+','AB-','O+','O-'] },
  unitsRequired: { type: Number, required: true, default: 1 },
  unitsFulfilled: { type: Number, default: 0 },
  hospitalName: { type: String, required: true }, // e.g., 'Rajiv Gandhi Govt General Hospital'
  hospitalAddress: { type: String, required: true },
  city: { type: String, default: 'Chennai' },
  emergencyLevel: { type: String, enum: ['CRITICAL', 'URGENT', 'STANDARD'], default: 'URGENT' },
  requestStatus: { type: String, enum: ['PENDING','APPROVED','MATCHED','FULFILLED','REJECTED','CANCELLED'], default: 'PENDING' },
  requiredBy: { type: Date, required: true },
  assignedDonors: [{ type: Schema.Types.ObjectId, ref: 'User' }]
});`}</pre>
              </div>
            </div>
          )}

          {activeTab === 'APIS' && (
            <div className="space-y-4">
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="p-3">Method</th>
                      <th className="p-3">Endpoint</th>
                      <th className="p-3">Access / RBAC</th>
                      <th className="p-3">Description & Privacy Guard</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr>
                      <td className="p-3 font-mono font-bold text-emerald-600">POST</td>
                      <td className="p-3 font-mono">/api/auth/register</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded bg-slate-100 font-mono text-[10px]">Public</span></td>
                      <td className="p-3 text-slate-600">Registers new user/donor; hashes password via bcrypt</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-blue-600">POST</td>
                      <td className="p-3 font-mono">/api/auth/login</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded bg-slate-100 font-mono text-[10px]">Public</span></td>
                      <td className="p-3 text-slate-600">Validates credentials and returns 30-day signed JWT Bearer token</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-amber-600">GET</td>
                      <td className="p-3 font-mono">/api/users/nearby-donors</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-mono text-[10px]">USER / ADMIN</span></td>
                      <td className="p-3 text-slate-600">Executes 2dsphere $near query; strips private emails & masks phones for users</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-emerald-600">POST</td>
                      <td className="p-3 font-mono">/api/requests</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-mono text-[10px]">USER / ADMIN</span></td>
                      <td className="p-3 text-slate-600">Creates transfusion requisition assigned to authenticated user</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-amber-600">GET</td>
                      <td className="p-3 font-mono">/api/requests/my-requests</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-mono text-[10px]">USER ONLY</span></td>
                      <td className="p-3 text-slate-600">Strictly filters by `requester: req.user._id` for user privacy</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-rose-600">POST</td>
                      <td className="p-3 font-mono">/api/sos/trigger</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-mono text-[10px]">ADMIN / CLINICAL</span></td>
                      <td className="p-3 text-slate-600">Broadcasts emergency beacon & calculates donors within 15 km</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-purple-600">GET</td>
                      <td className="p-3 font-mono">/api/admin/dashboard-stats</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-mono text-[10px]">ADMIN ONLY</span></td>
                      <td className="p-3 text-slate-600">Total users, donors, blood stock breakdown, live triage statistics</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-purple-600">PATCH</td>
                      <td className="p-3 font-mono">/api/admin/requests/:id/status</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-mono text-[10px]">ADMIN ONLY</span></td>
                      <td className="p-3 text-slate-600">Approve, reject, or assign donor to hospital request</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'GEOSPATIAL' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-900 text-slate-200 rounded-xl font-mono text-[11px] overflow-x-auto">
                <p className="text-emerald-400 font-bold mb-2">// MongoDB 2dsphere Geolocation Query ($near)</p>
                <pre>{`// Finding compatible donors within 15 km in Chennai, Tamil Nadu
const nearbyDonors = await User.find({
  isDonor: true,
  isAvailable: true,
  bloodGroup: { $in: ['O+', 'O-'] }, // Compatible donor match
  location: {
    $near: {
      $geometry: {
        type: 'Point',
        coordinates: [80.2707, 13.0827] // [Longitude, Latitude] of Chennai Central
      },
      $maxDistance: 15000 // 15,000 meters = 15 km
    }
  }
}).limit(20);`}</pre>
              </div>

              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
                <strong className="block mb-1 font-bold">Why GeoJSON Point [lng, lat] Order?</strong>
                MongoDB conforms strictly to the GeoJSON specification (RFC 7946), where coordinates are stored in <span className="font-mono font-bold">[longitude, latitude]</span> order. This enables spherical indexing on the earth's curvature without distortion.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Backend files located in <code className="font-mono font-semibold text-slate-700">/server</code> directory</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold transition-colors"
          >
            Close Viewer
          </button>
        </div>
      </div>
    </div>
  );
};
