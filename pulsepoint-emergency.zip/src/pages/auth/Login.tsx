import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BloodGroup, UserRole } from '../../types';
import {
  AlertOctagon,
  Shield,
  UserCheck,
  CheckCircle,
  ArrowRight,
  UserPlus,
} from 'lucide-react';

interface LoginProps {
  onSuccess: () => void;
}

export const Login: React.FC<LoginProps> = ({ onSuccess }) => {
  const { users, currentUser, loginAs, registerUser } = useApp();
  const [mode, setMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');

  // Registration state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('Metro City');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('O+');
  const [role, setRole] = useState<UserRole>('USER');
  const [isDonor, setIsDonor] = useState(true);

  const bloodGroups: BloodGroup[] = ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'];

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    registerUser({
      name,
      email,
      phone,
      city,
      bloodGroup,
      role,
      isDonor,
      donorAvailability: isDonor,
    });
    onSuccess();
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="w-12 h-12 rounded-xl bg-rose-600 text-white flex items-center justify-center mx-auto mb-3 shadow-md">
          <AlertOctagon className="w-6 h-6" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          PulsePoint Authentication & Role Access
        </h1>
        <p className="text-sm text-slate-500 mt-1 max-w-lg mx-auto">
          Sign in to your registered role or instantly switch profiles to test User and Admin workflows.
        </p>

        {/* Tab switch */}
        <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg text-xs font-medium mt-6">
          <button
            onClick={() => setMode('LOGIN')}
            className={`px-4 py-2 rounded-md transition-colors ${
              mode === 'LOGIN'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Quick Profile Switcher
          </button>
          <button
            onClick={() => setMode('REGISTER')}
            className={`px-4 py-2 rounded-md transition-colors ${
              mode === 'REGISTER'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Register New Account
          </button>
        </div>
      </div>

      {mode === 'LOGIN' ? (
        <div className="space-y-6">
          {/* Quick Select Personas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {users.map(u => {
              const isSelected = currentUser.id === u.id;
              const isAdmin = u.role === 'ADMIN';

              return (
                <div
                  key={u.id}
                  onClick={() => {
                    loginAs(u.id);
                    onSuccess();
                  }}
                  className={`p-4 rounded-xl border text-left cursor-pointer transition-all duration-150 ${
                    isSelected
                      ? 'border-rose-600 bg-rose-50/50 shadow-xs ring-1 ring-rose-600'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center font-mono font-bold text-sm ${
                          isAdmin
                            ? 'bg-slate-900 text-white'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {u.bloodGroup}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-semibold text-slate-900">
                            {u.name}
                          </h3>
                          {isSelected && (
                            <span className="flex items-center gap-1 text-[11px] font-medium text-rose-700 bg-rose-100 px-1.5 py-0.5 rounded">
                              <CheckCircle className="w-3 h-3" /> Active
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500">{u.email}</p>
                      </div>
                    </div>

                    <span
                      className={`text-[11px] font-mono font-semibold px-2 py-0.5 rounded ${
                        isAdmin
                          ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {u.role}
                    </span>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span>
                      {u.city} · {u.isDonor ? 'Registered Donor' : 'Patient / Requester'}
                    </span>
                    <span className="flex items-center gap-1 text-rose-600 font-medium hover:underline">
                      Continue <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
            <p className="font-semibold text-slate-800 mb-1">
              Role Access Overview:
            </p>
            <ul className="list-disc list-inside space-y-1">
              <li>
                <strong>Admin Mode:</strong> Full clinical approval rights, responder dispatch for SOS alerts, donor registry verification, inventory stock management.
              </li>
              <li>
                <strong>User Mode:</strong> 1-click SOS broadcast with GPS coordinates, blood transfusion requests, donor proximity map, and personal donation certificates.
              </li>
            </ul>
          </div>
        </div>
      ) : (
        /* Register New Account Form */
        <div className="max-w-xl mx-auto bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Dr. Jennifer Clark"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="+1 (555) 000-0000"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Blood Group
                </label>
                <select
                  value={bloodGroup}
                  onChange={e => setBloodGroup(e.target.value as BloodGroup)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 font-mono"
                >
                  {bloodGroups.map(bg => (
                    <option key={bg} value={bg}>
                      {bg}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  City / Region
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={e => setCity(e.target.value)}
                  placeholder="e.g. Metro City"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Account Role
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRole('USER')}
                  className={`p-2.5 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 ${
                    role === 'USER'
                      ? 'bg-rose-50 border-rose-500 text-rose-900 font-semibold'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <UserCheck className="w-4 h-4 text-rose-600" />
                  <span>User / Donor</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('ADMIN')}
                  className={`p-2.5 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 ${
                    role === 'ADMIN'
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-900 font-semibold'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <Shield className="w-4 h-4 text-indigo-600" />
                  <span>Admin / Blood Bank</span>
                </button>
              </div>
            </div>

            {role === 'USER' && (
              <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer pt-2">
                <input
                  type="checkbox"
                  checked={isDonor}
                  onChange={e => setIsDonor(e.target.checked)}
                  className="w-4 h-4 text-rose-600 rounded border-slate-300 focus:ring-rose-500"
                />
                <span>Register me as an active volunteer blood donor in proximity search</span>
              </label>
            )}

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white font-medium text-sm rounded-lg transition-colors flex items-center justify-center gap-2 mt-4 shadow-xs"
            >
              <UserPlus className="w-4 h-4" />
              <span>Create Account & Sign In</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
