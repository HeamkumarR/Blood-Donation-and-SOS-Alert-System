import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BloodGroup } from '../../types';
import {
  HeartHandshake,
  Search,
  ShieldCheck,
  Phone,
  CheckCircle2,
  Calendar,
  Award,
  Star,
} from 'lucide-react';

export const Donors: React.FC = () => {
  const { donors, toggleDonorVerification } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<BloodGroup | 'ALL'>('ALL');

  const bloodGroups: (BloodGroup | 'ALL')[] = [
    'ALL',
    'O-',
    'O+',
    'A-',
    'A+',
    'B-',
    'B+',
    'AB-',
    'AB+',
  ];

  const filteredDonors = donors.filter(d => {
    const matchesGroup = selectedGroup === 'ALL' || d.bloodGroup === selectedGroup;
    const matchesSearch =
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.phone.includes(searchQuery);
    return matchesGroup && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900">
            Donor Registry & Roster Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Supervise regional volunteer donors, verify medical eligibility, and manage emergency standby availability.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono font-medium text-slate-500 bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-xs">
          <span>{donors.length} registered donors</span>
          <span>·</span>
          <span className="text-emerald-700">
            {donors.filter(d => d.available).length} available now
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Blood group selector */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {bloodGroups.map(bg => (
              <button
                key={bg}
                onClick={() => setSelectedGroup(bg)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-colors shrink-0 ${
                  selectedGroup === bg
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {bg}
              </button>
            ))}
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search donors..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
            />
          </div>
        </div>
      </div>

      {/* Donors Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3">Donor Details</th>
                <th className="px-4 py-3">Blood Group</th>
                <th className="px-4 py-3">Proximity</th>
                <th className="px-4 py-3">Donations / Rating</th>
                <th className="px-4 py-3">Availability</th>
                <th className="px-4 py-3">Verification</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDonors.map(donor => (
                <tr key={donor.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-rose-50 text-rose-700 font-mono font-bold text-xs flex items-center justify-center border border-rose-200 shrink-0">
                        {donor.bloodGroup}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-slate-900">
                            {donor.name}
                          </span>
                          {donor.verified && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 font-mono">
                          {donor.phone} · {donor.city}
                        </p>
                      </div>
                    </div>
                  </td>

                  <td className="px-4 py-3.5">
                    <span className="font-mono font-bold text-slate-900 text-sm">
                      {donor.bloodGroup}
                    </span>
                  </td>

                  <td className="px-4 py-3.5">
                    <span className="font-mono text-slate-700 font-medium">
                      {donor.distanceKm} km
                    </span>
                  </td>

                  <td className="px-4 py-3.5">
                    <div className="space-y-0.5">
                      <span className="font-mono font-semibold text-slate-900">
                        {donor.totalDonations} units
                      </span>
                      <div className="flex items-center gap-1 text-[11px] text-amber-600">
                        <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                        <span className="font-mono">{donor.rating}</span>
                      </div>
                    </div>
                  </td>

                  <td className="px-4 py-3.5">
                    <span
                      className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                        donor.available
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-slate-100 text-slate-500 border border-slate-200'
                      }`}
                    >
                      {donor.available ? 'Ready' : 'Resting'}
                    </span>
                  </td>

                  <td className="px-4 py-3.5">
                    <button
                      onClick={() => toggleDonorVerification(donor.id)}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold flex items-center gap-1 border transition-colors ${
                        donor.verified
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {donor.verified ? (
                        <>
                          <CheckCircle2 className="w-3 h-3" /> Verified
                        </>
                      ) : (
                        'Unverified'
                      )}
                    </button>
                  </td>

                  <td className="px-4 py-3.5 text-right">
                    <a
                      href={`tel:${donor.phone}`}
                      className="px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-100 transition-colors inline-flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3 text-slate-500" />
                      <span>Call</span>
                    </a>
                  </td>
                </tr>
              ))}

              {filteredDonors.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No donors match current filter settings.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
